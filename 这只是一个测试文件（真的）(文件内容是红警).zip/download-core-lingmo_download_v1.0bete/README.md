# download-core

#### 介绍
the download core will upgrade at 2024/3/31 17:00~20:00

#### 软件架构和依赖包
[官网](https://www.python.org)

```
sudo apt-get python==3.8.0（liunx端可尝试）
```

```
pip install django==4.1.0
```

使用python django包来执行以下代码：
（需要转到该文件内）
```
python manage.py runserver
```
然后打开120.0.0.1:8000(一般情况下)

#### license

与django开源包一致，都是BSD-3