#### introduce
the download core will upgrade at 2024/3/31 17:00~20:00

#### Software architecture and dependencies

```
sudo apt-get python==3.8.0
```

```
pip install django==4.1.0
```

Use the Python Django package to execute the following code: (need to go to this file)

python manage.py runserver
Then turn on 120.0.0.1:8000 (generally)

#### license
Consistent with the django open source package, both are BSD-3