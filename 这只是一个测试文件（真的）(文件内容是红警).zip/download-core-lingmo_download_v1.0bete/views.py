import os  
from django.http import FileResponse, Http404  

try:
    def file_response_download(request):  
        # 文件路径  
        file_path = 'D:\\loginweb\\loginweb\\org.lingmo.zip'  
          
        # 确保文件存在  
        if not os.path.exists(file_path):  
            return Http404("File does not exist")  
          
        # 设置 Content-Disposition 头，以便浏览器知道如何处理下载的文件  
        # 直接将文件路径传递给 FileResponse，它会负责打开和关闭文件  
        responses= FileResponse(open(file_path, 'rb'), filename=os.path.basename(file_path))  
          
        # 返回响应  
        return responses
except:
    raise http404('system error 404')
